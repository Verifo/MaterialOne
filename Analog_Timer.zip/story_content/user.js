function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5kop9eMzHLT":
        Script1();
        break;
  }
}

function Script1()
{
  var JSdate = new Date();
var JSSeconds = JSdate.getSeconds();
var JSMinutes = JSdate.getMinutes();
var JSHours = JSdate.getHours();

if(JSHours>12){
JSHours = JSHours - 12;
}

var JSDOM = JSdate.getDate();
var JSMonth = JSdate.getMonth();
var JSDay = JSdate.getDay();
var player = GetPlayer();
player.SetVar("Seconds",JSSeconds);
player.SetVar("Minutes",JSMinutes);
player.SetVar("Hours",JSHours);
player.SetVar("DOM",JSDOM);
player.SetVar("Month",JSMonth);
player.SetVar("Day",JSDay);
}

